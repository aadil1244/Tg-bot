/*CMD
  command: /onStatus
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var r; try { r = JSON.parse(content); } catch(e) { return Bot.sendMessage("❌ Could not read status."); }
if (r.error) { return Bot.sendMessage("❌ " + r.error); }
var em = {"Completed":"✅","In progress":"🔄","Processing":"⏳","Pending":"⏳","Partial":"🟡","Canceled":"❌"};
Bot.sendMessage("📊 *Order Status*\n\n" + (em[r.status]||"ℹ️") + " Status: *" + r.status + "*\n▶️ Start count: " + (r.start_count||"-") + "\n🔻 Remains: " + (r.remains||"-"));
