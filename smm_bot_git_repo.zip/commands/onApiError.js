/*CMD
  command: /onApiError
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

Bot.sendMessage("⚠️ Provider is not responding right now. Please try again in a moment.");
