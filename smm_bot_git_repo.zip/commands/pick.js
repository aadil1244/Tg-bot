/*CMD
  command: /pick
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var cat = Bot.getProperty("CATALOG"), sid = String(params).trim(), s = null;
for (var i=0;i<cat.svcs.length;i++){ if (cat.svcs[i][0]===sid) s = cat.svcs[i]; }
if (!s) { return Bot.sendMessage("Service not found. Please start again."); }
User.setProperty("order", {sid:s[0], name:s[1], price:s[3], min:s[4], max:s[5]}, "json");
User.setProperty("step", "link", "string");
Bot.sendMessage("✅ *" + s[1] + "*\n💵 ₹" + s[3].toFixed(2) + " per 1000\n📉 Min: " + s[4] + " | 📈 Max: " + s[5] + "\n\n🔗 Now send the *link* (https://...)\nor /cancel");
