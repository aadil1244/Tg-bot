/*CMD
  command: /paid
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var p = String(params||"").trim().split(/\s+/);
var amt = parseFloat(p[0]), utr = String(p[1]||"").toUpperCase();
if (isNaN(amt) || amt < 10 || !/^[A-Z0-9]{6,35}$/.test(utr)) { return Bot.sendMessage("❌ Format: `/paid 100 123456789012` (min ₹10)"); }
var used = Bot.getProperty("UTRS") || {};
if (used[utr]) { return Bot.sendMessage("❌ This UTR was already submitted."); }
used[utr] = user.telegramid; Bot.setProperty("UTRS", used, "json");
Bot.sendMessage("📨 Payment submitted for review.\nAmount: ₹" + amt.toFixed(2) + "\nUTR: " + utr + "\nYou will be notified once approved.");
var admins = String(Bot.getProperty("ADMIN_IDS")||"").split(",");
for (var i=0;i<admins.length;i++){ if(admins[i]) Api.sendMessage({chat_id:admins[i], text:"💳 New payment\nUser: " + user.telegramid + " (" + (user.first_name||"") + ")\nAmount: ₹" + amt + "\nUTR: " + utr + "\n\nApprove: /approve " + user.telegramid + " " + amt + " " + utr}); }
