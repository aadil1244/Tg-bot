/*CMD
  command: /onSync
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var list;
try { list = JSON.parse(content); } catch(e) { return Bot.sendMessage("❌ Provider reply not understood."); }
if (!Array.isArray(list)) { return Bot.sendMessage("❌ Provider error: " + (list.error||"unknown")); }
var margin = parseFloat(Bot.getProperty("MARGIN_PERCENT")||"100");
var fx = parseFloat(Bot.getProperty("FX_RATE")||"1");
var filt = String(Bot.getProperty("CATEGORY_FILTER")||"").toLowerCase().split(",").map(function(x){return x.trim();}).filter(Boolean);
var maxSvc = parseInt(Bot.getProperty("MAX_SERVICES")||"400");
var cats = [], svcs = [];
for (var i=0;i<list.length && svcs.length<maxSvc;i++){
  var s = list[i];
  var cn = String(s.category||"Other");
  if (filt.length){ var ok=false; for (var j=0;j<filt.length;j++){ if (cn.toLowerCase().indexOf(filt[j])>=0) ok=true; } if(!ok) continue; }
  var ci = cats.indexOf(cn); if (ci<0){ cats.push(cn); ci = cats.length-1; }
  var price = parseFloat(s.rate)*fx*(1+margin/100);
  svcs.push([String(s.service), String(s.name).substr(0,70), ci, Math.round(price*10000)/10000, parseInt(s.min), parseInt(s.max)]);
}
Bot.setProperty("CATALOG", {cats:cats, svcs:svcs, at:Date.now()}, "json");
Bot.sendMessage("✅ Synced " + svcs.length + " services in " + cats.length + " categories.");
