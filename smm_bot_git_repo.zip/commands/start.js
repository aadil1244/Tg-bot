/*CMD
  command: /start
  help: Main menu
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 🏠 Menu
  group: 
CMD*/

Bot.sendKeyboard("🛒 New Order, 💰 Balance\n➕ Add Funds, 📦 My Orders\n🆘 Support", "👋 *Welcome to SMM Panel Bot*\n\nSocial media services — followers, likes, views & more.\nNo login needed, your Telegram account is your wallet.");
