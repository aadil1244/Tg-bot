/*CMD
  command: /support
  help: Contact support
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 🆘 Support
  group: 
CMD*/

Bot.sendMessage("🆘 *Support*\n\nContact: " + (Bot.getProperty("SUPPORT_CONTACT") || "@your_support_username") + "\nShare your Order ID for faster help.");
