/*CMD
  command: *
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var step = User.getProperty("step");
var o = User.getProperty("order");
if (!step || !o) { return Bot.sendMessage("Tap /start to open the menu."); }
var text = String(message||"").trim();
if (step === "link") {
  if (!/^https?:\/\/\S+$/i.test(text)) { return Bot.sendMessage("❌ Please send a valid link starting with https://"); }
  o.link = text; User.setProperty("order", o, "json");
  User.setProperty("step", "qty", "string");
  return Bot.sendMessage("🔢 Send *quantity* (" + o.min + " – " + o.max + ")");
}
if (step === "qty") {
  var q = parseInt(text);
  if (isNaN(q) || q < o.min || q > o.max) { return Bot.sendMessage("❌ Quantity must be between " + o.min + " and " + o.max + "."); }
  o.qty = q; o.charge = Math.round(o.price*q/1000*100)/100;
  User.setProperty("order", o, "json");
  User.setProperty("step", "", "string");
  var bal = Libs.ResourcesLib.userRes("balance");
  var txt = "🧾 *Order Summary*\n\n📦 " + o.name + "\n🔗 " + o.link + "\n🔢 Qty: " + q + "\n💵 Charge: *₹" + o.charge.toFixed(2) + "*\n💰 Balance: ₹" + Number(bal.value()).toFixed(2);
  Api.sendMessage({ text: txt, parse_mode:"Markdown", disable_web_page_preview:true,
    reply_markup:{inline_keyboard:[[{text:"✅ Confirm", callback_data:"/confirm"},{text:"❌ Cancel", callback_data:"/cancel"}]]} });
}
