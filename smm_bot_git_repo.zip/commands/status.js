/*CMD
  command: /status
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

HTTP.post({
  url: Bot.getProperty("SMM_API_URL") || "https://smpanel.in/api/v2",
  body: { key: Bot.getProperty("SMM_API_KEY"), action: "status", order: String(params).trim() },
  success: "/onStatus", error: "/onApiError"
});
