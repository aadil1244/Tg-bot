/*CMD
  command: /approve
  help: Admin: approve payment
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var admins = String(Bot.getProperty("ADMIN_IDS")||"").split(",");
if (admins.indexOf(String(user.telegramid)) < 0) { return Bot.sendMessage("⛔ Admin only."); }
var p = String(params||"").trim().split(/\s+/);
var uid = p[0], amt = parseFloat(p[1]), utr = p[2]||"";
if (!uid || isNaN(amt) || amt<=0) { return Bot.sendMessage("Usage: /approve <telegram_id> <amount> <utr>"); }
var done = Bot.getProperty("APPROVED") || {};
if (utr && done[utr]) { return Bot.sendMessage("⚠️ Already approved."); }
if (utr) { done[utr] = 1; Bot.setProperty("APPROVED", done, "json"); }
Libs.ResourcesLib.anotherUserRes("balance", uid).add(amt);
Bot.sendMessage("✅ Added ₹" + amt + " to " + uid);
Api.sendMessage({chat_id: uid, text: "✅ Payment approved! ₹" + amt.toFixed(2) + " added to your wallet."});
