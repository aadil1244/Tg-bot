/*CMD
  command: /neworder
  help: Start a new order
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 🛒 New Order
  group: 
CMD*/

var cat = Bot.getProperty("CATALOG");
if (!cat || !cat.cats || !cat.cats.length) { return Bot.sendMessage("Services are being updated. Please try again shortly."); }
User.setProperty("page", 0, "integer");
Bot.runCommand("/showcats");
