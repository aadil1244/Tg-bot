/*CMD
  command: /catpage
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

User.setProperty("page", parseInt(params), "integer");
Bot.runCommand("/showcats");
