/*CMD
  command: /addbal
  help: Admin: add/remove balance
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var admins = String(Bot.getProperty("ADMIN_IDS")||"").split(",");
if (admins.indexOf(String(user.telegramid)) < 0) { return Bot.sendMessage("⛔ Admin only."); }
var p = String(params||"").trim().split(/\s+/);
var uid = p[0], amt = parseFloat(p[1]);
if (!uid || isNaN(amt)) { return Bot.sendMessage("Usage: /addbal <telegram_id> <amount>"); }
var r = Libs.ResourcesLib.anotherUserRes("balance", uid);
if (amt >= 0) r.add(amt); else r.remove(-amt);
Bot.sendMessage("✅ Done. New balance of " + uid + ": ₹" + Number(r.value()).toFixed(2));
