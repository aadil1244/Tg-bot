/*CMD
  command: /confirm
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var o = User.getProperty("order");
if (!o || !o.qty) { return Bot.sendMessage("Nothing to confirm. Start a /neworder."); }
var bal = Libs.ResourcesLib.userRes("balance");
if (bal.value() < o.charge) { return Bot.sendMessage("❌ Not enough balance. Need ₹" + o.charge.toFixed(2) + ". Use ➕ Add Funds."); }
bal.remove(o.charge);               // charge first, refund if provider refuses
User.setProperty("pending", o, "json");
User.setProperty("order", null, "json");
HTTP.post({
  url: Bot.getProperty("SMM_API_URL") || "https://smpanel.in/api/v2",
  body: { key: Bot.getProperty("SMM_API_KEY"), action: "add", service: o.sid, link: o.link, quantity: o.qty },
  success: "/onOrderOk", error: "/onOrderFail"
});
Bot.sendMessage("⏳ Placing your order...");
