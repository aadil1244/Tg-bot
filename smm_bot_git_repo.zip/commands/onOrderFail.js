/*CMD
  command: /onOrderFail
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

// Network error: we cannot know if provider got the order, so do NOT auto-refund. Ask admin to verify.
var o = User.getProperty("pending");
Bot.sendMessage("⚠️ Network problem while placing the order. Your payment is on hold — support will verify and refund if it was not placed.");
var admins = String(Bot.getProperty("ADMIN_IDS")||"").split(",");
for (var i=0;i<admins.length;i++){ if(admins[i]) Api.sendMessage({chat_id:admins[i], text:"⚠️ Unknown order result. User " + user.telegramid + " charged ₹" + (o?o.charge:"?") + " for " + (o?o.name:"?") + " / " + (o?o.link:"") + ". Check provider, then /addbal " + user.telegramid + " amount if refund needed."}); }
