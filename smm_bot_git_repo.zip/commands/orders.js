/*CMD
  command: /orders
  help: My orders
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 📦 My Orders
  group: 
CMD*/

var list = User.getProperty("orders") || [];
if (!list.length) { return Bot.sendMessage("No orders yet. Tap 🛒 New Order."); }
var rows = [];
for (var i=0;i<Math.min(8,list.length);i++){ rows.push([{text:"#" + list[i].id + " · " + list[i].name.substr(0,30), callback_data:"/status " + list[i].id}]); }
Api.sendMessage({ text:"📦 *Your recent orders* — tap one for live status", parse_mode:"Markdown", reply_markup:{inline_keyboard: rows} });
