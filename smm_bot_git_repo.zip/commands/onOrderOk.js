/*CMD
  command: /onOrderOk
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var o = User.getProperty("pending");
var r; try { r = JSON.parse(content); } catch(e) { r = {}; }
var bal = Libs.ResourcesLib.userRes("balance");
if (!r.order) {
  if (o) bal.add(o.charge);
  User.setProperty("pending", null, "json");
  return Bot.sendMessage("❌ Provider rejected the order" + (r.error ? (": " + r.error) : "") + ".\n💸 ₹" + (o?o.charge.toFixed(2):"0") + " refunded.");
}
var list = User.getProperty("orders") || [];
list.unshift({id:String(r.order), name:o.name, qty:o.qty, charge:o.charge, link:o.link, t:Date.now()});
User.setProperty("orders", list.slice(0,20), "json");
User.setProperty("pending", null, "json");
Bot.sendMessage("✅✅ *Order placed!*\n\n🆔 Order ID: `" + r.order + "`\n💵 Charged: ₹" + o.charge.toFixed(2) + "\n💰 Balance: ₹" + Number(bal.value()).toFixed(2) + "\n\nCheck progress in 📦 My Orders.");
