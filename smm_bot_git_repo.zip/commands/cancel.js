/*CMD
  command: /cancel
  help: Cancel current action
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

User.setProperty("order", null, "json");
User.setProperty("step", "", "string");
Bot.sendMessage("❌ Cancelled.");
