/*CMD
  command: /showsvcs
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var p = params.split(" "); var ci = parseInt(p[0]), page = parseInt(p[1]||0), per = 8;
var cat = Bot.getProperty("CATALOG");
var list = cat.svcs.filter(function(s){ return s[2]===ci; });
var start = page*per, end = Math.min(list.length, start+per);
var rows = [];
for (var i=start;i<end;i++){
  var s = list[i];
  rows.push([{text: "₹" + (s[3]).toFixed(2) + "/1K · " + s[1].substr(0,38), callback_data: "/pick " + s[0]}]);
}
var nav = [];
if (page>0) nav.push({text:"⬅️ Prev", callback_data:"/showsvcs " + ci + " " + (page-1)});
if (end<list.length) nav.push({text:"Next ➡️", callback_data:"/showsvcs " + ci + " " + (page+1)});
if (nav.length) rows.push(nav);
rows.push([{text:"🔙 Categories", callback_data:"/showcats"}]);
Api.sendMessage({ text: "📦 *" + cat.cats[ci] + "*\nChoose a service:", parse_mode:"Markdown", reply_markup:{inline_keyboard: rows} });
