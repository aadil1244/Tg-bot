/*CMD
  command: /addfunds
  help: Add money
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: ➕ Add Funds
  group: 
CMD*/

var upi = Bot.getProperty("UPI_ID") || "(admin has not set UPI_ID)";
Bot.sendMessage("➕ *Add Funds (UPI)*\n\n1️⃣ Pay to UPI ID:\n`" + upi + "`\n2️⃣ Copy the *UTR / Reference ID* from your payment app.\n3️⃣ Send amount like this:\n\n`/paid 100 123456789012`\n\n(amount then UTR). Balance is added after admin verifies your payment.");
