/*CMD
  command: /showcats
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var cat = Bot.getProperty("CATALOG");
var page = parseInt(User.getProperty("page")||0), per = 8;
var rows = [];
var start = page*per, end = Math.min(cat.cats.length, start+per);
for (var i=start;i<end;i++){ rows.push([{text: cat.cats[i].substr(0,50), callback_data: "/showsvcs " + i + " 0"}]); }
var nav = [];
if (page>0) nav.push({text:"⬅️ Prev", callback_data:"/catpage " + (page-1)});
if (end<cat.cats.length) nav.push({text:"Next ➡️", callback_data:"/catpage " + (page+1)});
if (nav.length) rows.push(nav);
Api.sendMessage({ text: "📂 *Choose a category* (" + (page+1) + "/" + Math.ceil(cat.cats.length/per) + ")", parse_mode:"Markdown", reply_markup:{inline_keyboard: rows} });
