/*CMD
  command: /balance
  help: Wallet balance
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 💰 Balance
  group: 
CMD*/

var bal = Libs.ResourcesLib.userRes("balance");
Bot.sendMessage("💰 *Wallet Balance:* ₹" + Number(bal.value()).toFixed(2));
