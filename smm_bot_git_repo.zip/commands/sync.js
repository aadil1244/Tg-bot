/*CMD
  command: /sync
  help: Admin: refresh services
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

var admins = String(Bot.getProperty("ADMIN_IDS")||"").split(",");
if (admins.indexOf(String(user.telegramid)) < 0) { return Bot.sendMessage("⛔ Admin only."); }
Bot.sendMessage("⏳ Syncing services from provider...");
HTTP.post({
  url: Bot.getProperty("SMM_API_URL") || "https://smpanel.in/api/v2",
  body: { key: Bot.getProperty("SMM_API_KEY"), action: "services" },
  success: "/onSync", error: "/onApiError"
});
