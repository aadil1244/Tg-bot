/*CMD
  command: /help
  help: Help
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
  group: 
CMD*/

Bot.sendMessage("*Commands*\n/start – menu\n/neworder – place order\n/balance – wallet\n/addfunds – add money\n/orders – my orders\n/support – help");
