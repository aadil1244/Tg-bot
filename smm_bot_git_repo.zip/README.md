# SMM Panel Telegram Bot (Bots.Business)

Import via Tools -> Git Sync. Set bot Properties: SMM_API_KEY, ADMIN_IDS, UPI_ID, SUPPORT_CONTACT.
Then send /sync to the bot.
